# PopularMovies
Example of Android Architecture Components for themoviedb.org API

